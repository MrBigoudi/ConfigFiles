### [BetterDiscord](https://betterdiscord.net)

#### Installing manually

* Download using the [Dracula.theme.css](https://raw.githubusercontent.com/dracula/BetterDiscord/master/Dracula.theme.css) link or
* Download using the [Github .zip download](https://github.com/dracula/BetterDiscord/archive/master.zip) option and unzip them.

Move `Dracula.theme.css` file to your BetterDiscord themes folder.

#### Activating theme

1. Open Discord user settings
2. Navigate to the Themes section
3. Enable the Dracula Theme listed.
